"""
Scheduled maintenance tasks for the lyrics cache system.
These tasks are run periodically to maintain cache health and performance.
"""

import logging
from datetime import datetime, timedelta, timezone
from flask import current_app
from rq import get_current_job

from app.utils.cache_management import cache_manager

logger = logging.getLogger(__name__)


def clean_lyrics_cache(max_age_days=None):
    """
    Scheduled task to clean old lyrics cache entries.
    
    Args:
        max_age_days: Maximum age in days for cache entries (default from config)
        
    Returns:
        Dictionary with cleanup results
    """
    job = get_current_job()
    if job:
        job.meta['status'] = 'running'
        job.meta['started_at'] = datetime.now(timezone.utc).isoformat()
        job.save_meta()
    
    try:
        # Get max age from config or use provided value
        if max_age_days is None:
            max_age_days = current_app.config.get('LYRICS_CACHE_MAX_AGE_DAYS', 30)
        
        logger.info(f"Starting scheduled cache cleanup (max age: {max_age_days} days)")
        
        # Clean old entries
        cleanup_result = cache_manager.cleanup_expired_cache(max_age_days)
        
        # Get updated cache stats
        cache_stats = cache_manager.get_cache_stats()
        
        result = {
            'task': 'clean_lyrics_cache',
            'completed_at': datetime.now(timezone.utc).isoformat(),
            'removed_count': cleanup_result.get('total_cleaned', 0),
            'max_age_days': max_age_days,
            'remaining_entries': cache_stats.get('database_cache', {}).get('lyrics_cache_entries', 0),
            'status': 'completed'
        }
        
        logger.info(f"Cache cleanup completed: removed {cleanup_result.get('total_cleaned', 0)} entries")
        
        if job:
            job.meta.update(result)
            job.save_meta()
        
        return result
        
    except Exception as e:
        error_msg = f"Error during cache cleanup: {e}"
        logger.error(error_msg)
        
        result = {
            'task': 'clean_lyrics_cache',
            'completed_at': datetime.now(timezone.utc).isoformat(),
            'status': 'failed',
            'error': str(e)
        }
        
        if job:
            job.meta.update(result)
            job.save_meta()
        
        raise


def optimize_lyrics_cache():
    """
    Scheduled task to optimize lyrics cache storage.
    Removes duplicates and performs maintenance operations.
    
    Returns:
        Dictionary with optimization results
    """
    job = get_current_job()
    if job:
        job.meta['status'] = 'running'
        job.meta['started_at'] = datetime.now(timezone.utc).isoformat()
        job.save_meta()
    
    try:
        logger.info("Starting scheduled cache optimization")
        
        # Optimize cache storage
        optimization_result = cache_manager.optimize_cache()
        
        result = {
            'task': 'optimize_lyrics_cache',
            'completed_at': datetime.now(timezone.utc).isoformat(),
            'actions_taken': optimization_result.get('actions_taken', []),
            'optimization_completed': True,
            'current_stats': optimization_result.get('after_stats', {}),
            'status': 'completed'
        }
        
        logger.info(f"Cache optimization completed: {optimization_result.get('actions_taken', [])}")
        
        if job:
            job.meta.update(result)
            job.save_meta()
        
        return result
        
    except Exception as e:
        error_msg = f"Error during cache optimization: {e}"
        logger.error(error_msg)
        
        result = {
            'task': 'optimize_lyrics_cache',
            'completed_at': datetime.now(timezone.utc).isoformat(),
            'status': 'failed',
            'error': str(e)
        }
        
        if job:
            job.meta.update(result)
            job.save_meta()
        
        raise


def validate_cache_health():
    """
    Scheduled task to validate cache integrity and health.
    
    Returns:
        Dictionary with validation results
    """
    job = get_current_job()
    if job:
        job.meta['status'] = 'running'
        job.meta['started_at'] = datetime.now(timezone.utc).isoformat()
        job.save_meta()
    
    try:
        logger.info("Starting scheduled cache health validation")
        
        # Validate cache health
        health_result = cache_manager.get_cache_health()
        
        # Get cache statistics
        cache_stats = cache_manager.get_cache_stats()
        
        result = {
            'task': 'validate_cache_health',
            'completed_at': datetime.now(timezone.utc).isoformat(),
            'integrity_status': health_result.get('overall_status', 'unknown'),
            'checks': health_result.get('checks', {}),
            'cache_stats': cache_stats,
            'status': 'completed'
        }
        
        if health_result.get('overall_status') != 'healthy':
            logger.warning(f"Cache health validation found issues: {health_result.get('checks', {})}")
        else:
            logger.info("Cache health validation completed - system healthy")
        
        if job:
            job.meta.update(result)
            job.save_meta()
        
        return result
        
    except Exception as e:
        error_msg = f"Error during cache health validation: {e}"
        logger.error(error_msg)
        
        result = {
            'task': 'validate_cache_health',
            'completed_at': datetime.now(timezone.utc).isoformat(),
            'status': 'failed',
            'error': str(e)
        }
        
        if job:
            job.meta.update(result)
            job.save_meta()
        
        raise


def comprehensive_cache_maintenance():
    """
    Comprehensive cache maintenance task that combines multiple operations.
    
    Returns:
        Dictionary with maintenance results
    """
    job = get_current_job()
    if job:
        job.meta['status'] = 'running'
        job.meta['started_at'] = datetime.now(timezone.utc).isoformat()
        job.save_meta()
    
    try:
        logger.info("Starting comprehensive cache maintenance")
        
        maintenance_results = {
            'task': 'comprehensive_cache_maintenance',
            'started_at': datetime.now(timezone.utc).isoformat(),
            'operations': []
        }
        
        # 1. Clean old cache entries
        try:
            cleanup_result = clean_lyrics_cache()
            maintenance_results['operations'].append({
                'operation': 'cache_cleanup',
                'status': 'completed',
                'result': cleanup_result
            })
        except Exception as e:
            maintenance_results['operations'].append({
                'operation': 'cache_cleanup',
                'status': 'failed',
                'error': str(e)
            })
        
        # 2. Optimize cache storage
        try:
            optimization_result = optimize_lyrics_cache()
            maintenance_results['operations'].append({
                'operation': 'cache_optimization',
                'status': 'completed',
                'result': optimization_result
            })
        except Exception as e:
            maintenance_results['operations'].append({
                'operation': 'cache_optimization',
                'status': 'failed',
                'error': str(e)
            })
        
        # 3. Validate cache health
        try:
            health_result = validate_cache_health()
            maintenance_results['operations'].append({
                'operation': 'health_validation',
                'status': 'completed',
                'result': health_result
            })
        except Exception as e:
            maintenance_results['operations'].append({
                'operation': 'health_validation',
                'status': 'failed',
                'error': str(e)
            })
        
        # 4. Generate comprehensive report
        try:
            report = cache_manager.export_cache_report()
            maintenance_results['operations'].append({
                'operation': 'report_generation',
                'status': 'completed',
                'result': report
            })
        except Exception as e:
            maintenance_results['operations'].append({
                'operation': 'report_generation',
                'status': 'failed',
                'error': str(e)
            })
        
        maintenance_results.update({
            'completed_at': datetime.now(timezone.utc).isoformat(),
            'status': 'completed',
            'successful_operations': len([op for op in maintenance_results['operations'] if op['status'] == 'completed']),
            'failed_operations': len([op for op in maintenance_results['operations'] if op['status'] == 'failed'])
        })
        
        logger.info(f"Comprehensive cache maintenance completed: {maintenance_results['successful_operations']} successful, {maintenance_results['failed_operations']} failed")
        
        if job:
            job.meta.update(maintenance_results)
            job.save_meta()
        
        return maintenance_results
        
    except Exception as e:
        error_msg = f"Error during comprehensive cache maintenance: {e}"
        logger.error(error_msg)
        
        result = {
            'task': 'comprehensive_cache_maintenance',
            'completed_at': datetime.now(timezone.utc).isoformat(),
            'status': 'failed',
            'error': str(e)
        }
        
        if job:
            job.meta.update(result)
            job.save_meta()
        
        raise


def warm_cache_scheduled():
    """
    Scheduled task to warm the cache with frequently accessed data.
    
    Returns:
        Dictionary with warming results
    """
    job = get_current_job()
    if job:
        job.meta['status'] = 'running'
        job.meta['started_at'] = datetime.now(timezone.utc).isoformat()
        job.save_meta()
    
    try:
        logger.info("Starting scheduled cache warming")
        
        # Warm the cache
        warming_result = cache_manager.warm_cache()
        
        result = {
            'task': 'warm_cache_scheduled',
            'completed_at': datetime.now(timezone.utc).isoformat(),
            'warmed_items': warming_result.get('warmed_items', 0),
            'status': 'completed'
        }
        
        logger.info(f"Cache warming completed: {warming_result.get('warmed_items', 0)} items warmed")
        
        if job:
            job.meta.update(result)
            job.save_meta()
        
        return result
        
    except Exception as e:
        error_msg = f"Error during cache warming: {e}"
        logger.error(error_msg)
        
        result = {
            'task': 'warm_cache_scheduled',
            'completed_at': datetime.now(timezone.utc).isoformat(),
            'status': 'failed',
            'error': str(e)
        }
        
        if job:
            job.meta.update(result)
            job.save_meta()
        
        raise


def schedule_cache_maintenance_jobs(app):
    """
    Schedule all cache maintenance jobs with the Flask app scheduler.
    
    Args:
        app: Flask application instance
    """
    try:
        if not hasattr(app, 'scheduler') or not app.scheduler:
            logger.warning("Scheduler not available - cache maintenance jobs not scheduled")
            return
        
        logger.info("Scheduling cache maintenance jobs")
        
        # Schedule daily cache cleanup at 2 AM
        app.scheduler.add_job(
            id='daily_cache_cleanup',
            func=clean_lyrics_cache,
            trigger='cron',
            hour=2,
            minute=0,
            replace_existing=True,
            kwargs={'max_age_days': 30}
        )
        
        # Schedule weekly cache optimization on Sundays at 3 AM
        app.scheduler.add_job(
            id='weekly_cache_optimization',
            func=optimize_lyrics_cache,
            trigger='cron',
            day_of_week=6,  # Sunday
            hour=3,
            minute=0,
            replace_existing=True
        )
        
        # Schedule daily cache health validation at 1 AM
        app.scheduler.add_job(
            id='daily_cache_health_check',
            func=validate_cache_health,
            trigger='cron',
            hour=1,
            minute=0,
            replace_existing=True
        )
        
        # Schedule weekly comprehensive maintenance on Sundays at 4 AM
        app.scheduler.add_job(
            id='weekly_comprehensive_maintenance',
            func=comprehensive_cache_maintenance,
            trigger='cron',
            day_of_week=6,  # Sunday
            hour=4,
            minute=0,
            replace_existing=True
        )
        
        # Schedule daily cache warming at startup and 6 AM
        app.scheduler.add_job(
            id='daily_cache_warming',
            func=warm_cache_scheduled,
            trigger='cron',
            hour=6,
            minute=0,
            replace_existing=True
        )
        
        logger.info("Cache maintenance jobs scheduled successfully")
        
    except Exception as e:
        logger.error(f"Error scheduling cache maintenance jobs: {e}") 