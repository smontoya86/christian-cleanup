"""Test tasks for RQ queue system validation."""
import time
import logging
from rq import get_current_job

logger = logging.getLogger(__name__)

def test_job(duration=5):
    """Simple test job that simulates work."""
    job = get_current_job()
    job_id = job.id if job else "test-mode"
    logger.info(f"[Test Job] Starting job {job_id}")
    
    # Simulate some work
    logger.info("[Test Job] Doing some work...")
    time.sleep(duration)
    
    result = {"message": "Job completed successfully", "duration": duration}
    logger.info(f"[Test Job] Job complete: {result}")
    return result
